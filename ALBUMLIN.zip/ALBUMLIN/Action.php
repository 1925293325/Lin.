<?php

namespace TypechoPlugin\ALBUMLIN;

use Typecho\Widget;
use Typecho\Db;
use Typecho\Db\Exception;
use Widget\Options;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * 相册页面处理器 - 
 */
class Action extends Widget
{
    /**
     * 执行函数
     */
    public function execute()
    {
        // 无需执行特定查询，数据在render中处理
    }

    /**
     * 渲染相册页面
     */
    public function render()
    {
        // 获取配置
        $options = Options::alloc()->plugin('ALBUMLIN');
        
        // 获取参数
        $categoryId = $this->request->get('category', $options->category);
        $categoryId = intval($categoryId);
        if ($categoryId <= 0) $categoryId = 2;
        
        // 获取所有图片
        $allImages = $this->getAllImages($categoryId);
        
        // 准备模板变量
        $pageTitle = '相册 - ' . Options::alloc()->title;
        $albumTitle = $options->title;
        $albumDesc = $options->description;
        $headerBg = $options->headerBg;
        $gridColumns = intval($options->gridColumns) ?: 3; // 默认3列
        
        // 包含模板文件
        include __DIR__ . '/views/album.php';
    }

    /**
     * 获取所有图片（扁平化）
     */
    private function getAllImages(int $categoryId): array
    {
        $db = Db::get();
        $allImages = [];
        
        try {
            $posts = $db->fetchAll(
                $db->select('table.contents.cid', 'table.contents.text')
                    ->from('table.relationships')
                    ->join('table.contents', 'table.contents.cid = table.relationships.cid', Db::INNER_JOIN)
                    ->where('table.relationships.mid = ?', $categoryId)
                    ->where('table.contents.type = ?', 'post')
                    ->where('table.contents.status = ?', 'publish')
                    ->order('table.contents.created', Db::SORT_DESC)
            );
        } catch (Exception $e) {
            return [];
        }
        
        foreach ($posts as $post) {
            $images = $this->extractImagesFromMarkdown($post['text']);
            
            foreach ($images as $img) {
                $safeUrl = $this->safeImageUrl($img['url']);
                if ($safeUrl) {
                    $allImages[] = [
                        'url' => $safeUrl,
                        'thumb' => $safeUrl,
                        'title' => $img['title'] ?: '图片'
                    ];
                }
            }
        }
        
        return $allImages;
    }

    /**
     * 过滤不安全的图片 URL
     */
    private function safeImageUrl(string $url): string
    {
        $url = trim($url);
        if (preg_match('/^(https?:|data:image|\/)/i', $url)) {
            return $url;
        }
        if (strpos($url, '//') === 0) {
            return 'https:' . $url;
        }
        return '';
    }

    /**
     * 从 Markdown 提取图片
     */
    private function extractImagesFromMarkdown(string $text): array
    {
        $images = [];
        $definitions = [];
        
        preg_match_all('/^\s*\[([^\]]+)\]:\s*(\S+)(?:\s+(?:"|\')([^"\'"]+)(?:"|\'))?\s*$/m', $text, $matches, PREG_SET_ORDER);
        foreach ($matches as $match) {
            $definitions[trim($match[1])] = trim($match[2]);
        }
        
        preg_match_all('/!\[([^\]]*)\]\[([^\]]+)\]/', $text, $matches, PREG_SET_ORDER);
        foreach ($matches as $match) {
            $alt = trim($match[1]);
            $id = trim($match[2]);
            if (isset($definitions[$id])) {
                $images[] = [
                    'title' => $alt ?: '无标题',
                    'url' => $definitions[$id]
                ];
            }
        }
        
        preg_match_all('/!\[([^\]]*)\]\(([^)]+)\)/', $text, $matches, PREG_SET_ORDER);
        foreach ($matches as $match) {
            $images[] = [
                'title' => trim($match[1]) ?: '无标题',
                'url' => trim($match[2])
            ];
        }
        
        return $images;
    }
}
