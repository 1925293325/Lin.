<?php

namespace TypechoPlugin\LENS;

use Typecho\Widget;
use Typecho\Db;
use Typecho\Db\Exception;
use Widget\Options;
use Utils\Helper;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * 相册页面处理器 - LENS
 */
class Action extends Widget
{
    /**
     * 执行函数
     */
    public function execute()
    {
        // 无需执行特定查询，数据在render中处理
    }

    /**
     * 渲染相册页面
     */
    public function render()
    {
        // 获取配置
        $options = Options::alloc()->plugin('LENS');
        
        // 获取参数 - 支持逗号分隔的多个分类ID
        $categoryParam = $this->request->get('category', $options->category);
        
        // 解析分类ID（空数组表示"所有分类"）
        $categoryIds = $this->parseCategoryIds($categoryParam);
        
        // 获取所有图片（空数组 = 不限制分类）
        $allImages = $this->getAllImages($categoryIds);
        
        // 准备模板变量
        $pageTitle = '相册 - ' . Options::alloc()->title;
        $albumTitle = $options->title;
        $albumDesc = $options->description;
        
        // 处理背景图路径（如果是相对路径，转为完整URL）
        $headerBg = $options->headerBg;
        if (!preg_match('/^(https?:|\/\/)/i', $headerBg)) {
            // 相对路径，拼接插件目录URL
            $headerBg = Helper::options()->pluginUrl . '/LENS/' . ltrim($headerBg, '/');
        }
        
        $gridColumns = intval($options->gridColumns) ?: 3;
        
        // 包含模板文件
        include __DIR__ . '/views/lens.php';
    }

    /**
     * 解析逗号分隔的分类ID字符串
     * 返回空数组表示"所有分类"（不限制）
     */
    private function parseCategoryIds($categoryParam): array
    {
        // 如果为空、0、"0"，返回空数组（表示所有分类）
        if (empty($categoryParam) || $categoryParam === '0' || $categoryParam === 0) {
            return [];
        }
        
        // 如果是数组直接使用
        if (is_array($categoryParam)) {
            $result = array_filter(array_map('intval', $categoryParam));
            return array_values(array_unique($result));
        }
        
        // 字符串按逗号分割
        $ids = explode(',', $categoryParam);
        $result = [];
        foreach ($ids as $id) {
            $id = intval(trim($id));
            if ($id > 0) { // 只保留正整数
                $result[] = $id;
            }
        }
        
        // 去重并重新索引
        $result = array_values(array_unique($result));
        
        // 如果解析后为空，返回空数组（表示所有分类）
        return empty($result) ? [] : $result;
    }

    /**
     * 截断标题到7个字
     */
    private function truncateTitle(string $title): string
    {
        $title = trim($title);
        if (empty($title)) return '无标题';
        
        if (mb_strlen($title, 'UTF-8') > 7) {
            return mb_substr($title, 0, 7, 'UTF-8') . '...';
        }
        return $title;
    }

    /**
     * 获取所有图片
     * @param array $categoryIds 分类ID数组，空数组表示不限制分类（所有文章）
     */
    private function getAllImages(array $categoryIds): array
    {
        $db = Db::get();
        $allImages = [];
        
        try {
            // 构建基础查询（从contents表）
            $select = $db->select('table.contents.cid', 'table.contents.text', 'table.contents.created', 'table.contents.title')
                ->from('table.contents')
                ->where('table.contents.type = ?', 'post')
                ->where('table.contents.status = ?', 'publish');
            
            // 如果指定了分类ID数组，则关联relationships表并添加IN条件
            if (!empty($categoryIds)) {
                $select = $select->join('table.relationships', 'table.contents.cid = table.relationships.cid', Db::INNER_JOIN)
                                 ->where('table.relationships.mid IN ?', $categoryIds);
            }
            
            // 添加排序（倒序）
            $select = $select->order('table.contents.created', Db::SORT_DESC);
            
            $posts = $db->fetchAll($select);
            
        } catch (Exception $e) {
            return [];
        }
        
        // 后续处理逻辑不变...
        foreach ($posts as $post) {
            $images = $this->extractImagesFromMarkdown($post['text']);
            $postDate = date('Y/n/j', $post['created']);
            $postTitle = $this->truncateTitle($post['title'] ?? '');
            
            foreach ($images as $img) {
                $safeUrl = $this->safeImageUrl($img['url']);
                if ($safeUrl) {
                    $allImages[] = [
                        'url' => $safeUrl,
                        'thumb' => $safeUrl,
                        'title' => $postTitle,
                        'date' => $postDate
                    ];
                }
            }
        }
        
        return $allImages;
    }

    /**
     * 过滤不安全的图片 URL
     */
    private function safeImageUrl(string $url): string
    {
        $url = trim($url);
        if (preg_match('/^(https?:|data:image|\/)/i', $url)) {
            return $url;
        }
        if (strpos($url, '//') === 0) {
            return 'https:' . $url;
        }
        return '';
    }

    /**
     * 从 Markdown 提取图片
     */
    private function extractImagesFromMarkdown(string $text): array
    {
        $images = [];
        $definitions = [];
        
        // 提取引用定义
        preg_match_all('/^\s*\[([^\]]+)\]:\s*(\S+)(?:\s+(?:"|\')([^"\'"]+)(?:"|\'))?\s*$/m', $text, $matches, PREG_SET_ORDER);
        foreach ($matches as $match) {
            $definitions[trim($match[1])] = trim($match[2]);
        }
        
        // 提取引用式图片 ![alt][id]
        preg_match_all('/!\[([^\]]*)\]\[([^\]]+)\]/', $text, $matches, PREG_SET_ORDER);
        foreach ($matches as $match) {
            $alt = trim($match[1]);
            $id = trim($match[2]);
            if (isset($definitions[$id])) {
                $images[] = [
                    'title' => $alt ?: '无标题',
                    'url' => $definitions[$id]
                ];
            }
        }
        
        // 提取行内式图片 ![alt](url)
        preg_match_all('/!\[([^\]]*)\]\(([^)]+)\)/', $text, $matches, PREG_SET_ORDER);
        foreach ($matches as $match) {
            $images[] = [
                'title' => trim($match[1]) ?: '无标题',
                'url' => trim($match[2])
            ];
        }
        
        return $images;
    }
}
