<?php

namespace TypechoPlugin\AlbumGallery;

use Typecho\Widget;
use Typecho\Db;
use Typecho\Db\Exception;
use Widget\Options;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * 相册页面处理器
 */
class Action extends Widget
{
    /**
     * 执行函数
     */
    public function execute()
    {
        // 无需执行特定查询，数据在render中处理
    }

    /**
     * 渲染相册页面
     */
    public function render()
    {
        // 获取配置
        $options = Options::alloc()->plugin('AlbumGallery');
        
        // 获取参数
        $categoryId = $this->request->get('category', $options->category);
        $categoryId = intval($categoryId);
        if ($categoryId <= 0) $categoryId = 2;
        
        // 获取数据
        $articles = $this->getArticlesWithImages($categoryId);
        $allImages = [];
        foreach ($articles as $article) {
            foreach ($article['images'] as $img) {
                $allImages[] = $img;
            }
        }
        
        // 准备模板变量
        $pageTitle = '相册 - ' . Options::alloc()->title;
        $albumTitle = $options->title;
        $albumDesc = str_replace('{year}', date('Y'), $options->description) . ' · ' . date('m月d日');
        $headerBg = !empty($allImages) ? $allImages[0]['thumb'] : $options->headerBg;
        
        // 包含模板文件
        include __DIR__ . '/views/album.php';
    }

    /**
     * 获取文章及其图片
     */
    private function getArticlesWithImages(int $categoryId): array
    {
        $db = Db::get();
        $options = Options::alloc()->plugin('AlbumGallery');
        
        try {
            // 查询该分类下已发布的文章
            $posts = $db->fetchAll(
                $db->select('table.contents.cid', 'table.contents.title', 'table.contents.text')
                    ->from('table.relationships')
                    ->join('table.contents', 'table.contents.cid = table.relationships.cid', Db::INNER_JOIN)
                    ->where('table.relationships.mid = ?', $categoryId)
                    ->where('table.contents.type = ?', 'post')
                    ->where('table.contents.status = ?', 'publish')
                    ->order('table.contents.created', Db::SORT_DESC)
            );
        } catch (Exception $e) {
            return [];
        }
        
        $articles = [];
        
        foreach ($posts as $post) {
            $rawImages = $this->extractImagesFromMarkdown($post['text']);
            $safeImages = [];
            
            foreach ($rawImages as $img) {
                $safeUrl = $this->safeImageUrl($img['url']);
                if ($safeUrl) {
                    $img['url'] = $safeUrl;
                    $img['thumb'] = $this->getThumbnailUrl(
                        $safeUrl, 
                        intval($options->thumbWidth), 
                        intval($options->thumbHeight), 
                        $options->cropMode == '1'
                    );
                    $safeImages[] = $img;
                }
            }
            
            if (!empty($safeImages)) {
                $articles[] = [
                    'title' => $post['title'],
                    'images' => $safeImages
                ];
            }
        }
        
        return $articles;
    }

    /**
     * 生成缩略图 URL（支持云存储）
     */
    private function getThumbnailUrl(string $url, int $width = 400, int $height = 0, bool $crop = false): string
    {
        if (empty($url)) return $url;
        $url = str_replace(' ', '%20', $url);
        
        $options = Options::alloc()->plugin('AlbumGallery');
        
        // 七牛云
        if (!empty($options->qiniuDomain) && strpos($url, $options->qiniuDomain) !== false) {
            if ($height > 0) {
                $mode = $crop ? '1' : '2';
                return $url . "?imageView2/{$mode}/w/{$width}/h/{$height}";
            } else {
                return $url . "?imageView2/2/w/{$width}";
            }
        }
        
        // 又拍云
        if (!empty($options->upyunDomain) && strpos($url, $options->upyunDomain) !== false) {
            if ($height > 0) {
                return $url . "!/both/{$width}x{$height}";
            } else {
                return $url . "!/fw/{$width}";
            }
        }
        
        // 阿里云 OSS
        if (!empty($options->ossDomain) && strpos($url, $options->ossDomain) !== false) {
            $ossParams = "x-oss-process=image/resize";
            if ($height > 0 && $crop) {
                $ossParams .= ",m_fixed,w_{$width},h_{$height}";
            } elseif ($height > 0 && !$crop) {
                $ossParams .= ",m_lfit,w_{$width},h_{$height}";
            } else {
                $ossParams .= ",w_{$width}";
            }
            return $url . '?' . $ossParams;
        }
        
        return $url;
    }

    /**
     * 过滤不安全的图片 URL
     */
    private function safeImageUrl(string $url): string
    {
        $url = trim($url);
        if (preg_match('/^(https?:|data:image|\/)/i', $url)) {
            return $url;
        }
        if (strpos($url, '//') === 0) {
            return 'https:' . $url;
        }
        return '';
    }

    /**
     * 从 Markdown 提取图片
     */
    private function extractImagesFromMarkdown(string $text): array
    {
        $images = [];
        $definitions = [];
        
        // 引用定义 [id]: url
        preg_match_all('/^\s*\[([^\]]+)\]:\s*(\S+)(?:\s+(?:"|\')([^"\'"]+)(?:"|\'))?\s*$/m', $text, $matches, PREG_SET_ORDER);
        foreach ($matches as $match) {
            $definitions[trim($match[1])] = trim($match[2]);
        }
        
        // 引用式图片 ![alt][id]
        preg_match_all('/!\[([^\]]*)\]\[([^\]]+)\]/', $text, $matches, PREG_SET_ORDER);
        foreach ($matches as $match) {
            $alt = trim($match[1]);
            $id = trim($match[2]);
            if (isset($definitions[$id])) {
                $images[] = [
                    'title' => $alt ?: '无标题',
                    'url' => $definitions[$id]
                ];
            }
        }
        
        // 行内式图片 ![alt](url)
        preg_match_all('/!\[([^\]]*)\]\(([^)]+)\)/', $text, $matches, PREG_SET_ORDER);
        foreach ($matches as $match) {
            $images[] = [
                'title' => trim($match[1]) ?: '无标题',
                'url' => trim($match[2])
            ];
        }
        
        return $images;
    }
}
