<?php

namespace TypechoPlugin\LENS;

use Typecho\Plugin\PluginInterface;
use Typecho\Widget\Helper\Form;
use Typecho\Widget\Helper\Form\Element\Text;
use Typecho\Widget\Helper\Form\Element\Radio;
use Utils\Helper;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * 相册 - LENS
 *
 * @package LENS
 * @author Lin./https://linyu.live
 * @version 1.2.1
 */
class Plugin implements PluginInterface
{
    /**
     * 激活插件方法
     */
    public static function activate()
    {
        Helper::addRoute('lens', '/lens', 'LENS_Action', 'render');
        return _t('相册插件已激活，访问 你的域名/lens 查看相册');
    }

    /**
     * 禁用插件方法
     */
    public static function deactivate()
    {
        Helper::removeRoute('lens');
        return _t('相册插件已禁用');
    }

    /**
     * 获取插件配置面板
     */
    public static function config(Form $form)
    {
        // 相册标题
        $title = new Text('title', null, '我的相册', _t('相册标题'), _t('显示在顶栏和首图左下角的大标题'));
        $form->addInput($title);
        
        // 相册副标题
        $description = new Text('description', null, 'Scenery along the way', _t('相册副标题'), _t('显示在首图左下角的小字/英文'));
        $form->addInput($description);
        
        // 默认分类ID - 支持多个，逗号分隔
        $category = new Text('category', null, '0', _t('默认分类ID'), _t('支持多个分类ID，用英文逗号分隔，如：2,3,5<br>填 0 或留空则显示所有分类的文章'));
        $form->addInput($category);
        
        // 头部背景图 - 相对于插件目录的路径
        $defaultBg = 'img/photo.webp';
        
        $headerBg = new Text('headerBg', null, $defaultBg, _t('首图背景'), _t('相对于插件目录的路径（如 img/photo.webp）或完整URL（如 https://xxx.com/xx.jpg）'));
        $form->addInput($headerBg);
        
        // 网格布局列数
        $gridColumns = new Radio('gridColumns', 
            ['3' => _t('三列网格（小图，密集瀑布流）'), '2' => _t('双列网格（大图，带日期卡片）')], 
            '3', 
            _t('网格布局')
        );
        $form->addInput($gridColumns);
    }

    /**
     * 个人用户的配置面板
     */
    public static function personalConfig(Form $form)
    {
    }
}
