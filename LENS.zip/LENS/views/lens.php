<?php
/**
 * 相册模板 - LENS
 * 双列模式：文章图片堆叠显示（白色卡片样式）
 * 三列模式：单张瀑布流，点击全屏预览
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="<?php echo \Widget\Options::alloc()->charset(); ?>">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    
    <style>
        :root{
            --theme:#ff5a5f;
            --bg:#f5f5f5;
            --font-sans: -apple-system, "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "WenQuanYi Micro Hei", sans-serif;
            --font-serif: "Noto Serif SC", "Source Han Serif SC", "STSong", "SimSun", "FangSong", serif;
        }
        *{box-sizing:border-box;margin:0;padding:0;font-family:var(--font-sans);}
        body{background:var(--bg);color:#333;overflow-x:hidden;font-weight:400;line-height:1.6;}
        
        @media (min-width: 768px) {
            body {background: #f0f0f0;}
            .page-container {
                max-width: 900px;
                margin: 0 auto;
                background: #fff;
                box-shadow: 0 0 20px rgba(0,0,0,0.08);
                min-height: 100vh;
            }
        }
        @media (min-width: 1200px) {
            .page-container {max-width: 1000px;}
        }
        
        /* 顶栏 */
        .top-bar{
            position:fixed;
            top:0;
            left:0;
            right:0;
            height:56px;
            background:#fff;
            z-index:1000;
            display:flex;
            align-items:center;
            justify-content:center;
            padding:0 20px;
            box-shadow:0 1px 3px rgba(0,0,0,.05);
        }
        .top-bar-title{
            font-size:1.2rem;
            font-weight:500;
            color:#333;
            letter-spacing:2px;
            text-decoration:none;
            transition:opacity 0.2s;
        }
        .top-bar-title:hover{opacity:0.7;}
        
        /* 头部大图 */
        header{
            position:relative;
            height:35vh;
            min-height:220px;
            margin:56px 0 0;
            background:url("<?php echo htmlspecialchars($headerBg); ?>") center/cover;
            display:flex;
            align-items:flex-end;
            justify-content:flex-start;
            overflow:hidden;
        }
        header::after{
            content:"";
            position:absolute;
            inset:0;
            background:linear-gradient(180deg,rgba(0,0,0,.1) 0%,rgba(0,0,0,.5) 100%);
        }
        .header-content{
            position:relative;
            z-index:2;
            padding:25px 30px;
            text-align:left;
            color:#fff;
        }
        .header-title{
            font-size:1.8rem;
            font-weight:600;
            letter-spacing:4px;
            margin-bottom:8px;
            font-family:var(--font-serif);
            text-shadow:0 2px 8px rgba(0,0,0,.5);
        }
        .header-subtitle{
            font-size:0.9rem;
            font-weight:300;
            letter-spacing:2px;
            opacity:.9;
            text-shadow:0 1px 4px rgba(0,0,0,.4);
            font-family:var(--font-serif);
        }
        
        main{
            max-width:100%;
            margin:0;
            padding:20px;
            background:#fff;
        }
        
        /* === 三列网格（原有样式不变） === */
        .gallery-3col{
            display:grid;
            gap:8px;
            background:#fff;
            grid-template-columns:repeat(3, 1fr);
        }
        .gallery-3col .polaroid{
            position:relative;
            background:#fff;
            overflow:hidden;
            cursor:zoom-in;
            transition:transform 0.2s ease;
            border-radius:4px;
        }
        .gallery-3col .polaroid:hover{transform:scale(1.02); z-index:10;}
        .gallery-3col .polaroid::before{
            content:"";
            display:block;
            padding-bottom:100%;
        }
        .gallery-3col .polaroid img{
            position:absolute;
            top:0;
            left:0;
            width:100%;
            height:100%;
            object-fit:cover;
            display:block;
        }
        
        /* === 双列文章卡片（新样式 - 白色卡片） === */
        .gallery-2col {
            display: grid;
            gap: 16px;
            background: #fff;
            grid-template-columns: repeat(2, 1fr);
            padding: 8px;
        }
        
        .article-card {
            position: relative;
            background: #fff;
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 2px 12px rgba(0,0,0,0.06);
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .article-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 24px rgba(0,0,0,0.12);
        }
        
        /* 图片容器 - 统一外观（单张和堆叠一样） */
        .stack-container {
            position: relative;
            width: 100%;
            padding-bottom: 75%; /* 4:3 比例，接近截图效果 */
            background: #f8f8f8;
            overflow: hidden;
            border-radius: 16px 16px 0 0;
        }
        
        /* 堆叠效果 - 仅非单张时显示，但外观与单张一致（白色圆角） */
        .article-card:not(.single) .stack-container::before,
        .article-card:not(.single) .stack-container::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            border-radius: 16px 16px 0 0;
            background-size: cover;
            background-position: center;
            z-index: 0;
            transition: all 0.3s ease;
        }
        
        /* 第二张（底层）*/
        .article-card:not(.single) .stack-container::before {
            transform: translate(3px, 3px) scale(0.98);
            background-color: #eee;
            z-index: -2;
            opacity: 0.7;
        }
        
        /* 第三张（更底层）*/
        .article-card:not(.single) .stack-container::after {
            transform: translate(6px, 6px) scale(0.96);
            background-color: #e0e0e0;
            z-index: -3;
            opacity: 0.5;
        }
        
        /* 主图（顶层）*/
        .stack-main {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            overflow: hidden;
            border-radius: 16px 16px 0 0;
            z-index: 1;
            background: #fff;
        }
        
        .stack-main img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.3s ease;
        }
        
        .article-card:hover .stack-main img {
            transform: scale(1.03);
        }
        
        /* 图片数量徽章 - 仅非单张显示，其他外观与单张完全一致 */
        .image-count {
            position: absolute;
            top: 12px;
            right: 12px;
            background: rgba(0,0,0,0.65);
            color: #fff;
            padding: 5px 10px;
            border-radius: 16px;
            font-size: 0.8rem;
            font-weight: 500;
            z-index: 10;
            backdrop-filter: blur(4px);
            display: flex;
            align-items: center;
            gap: 4px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.15);
        }
        
        .image-count::before {
            content: '◈';
            font-size: 0.65rem;
        }
        
        /* 单张图隐藏徽章 */
        .article-card.single .image-count {
            display: none;
        }
        
        /* 文章信息区 - 模仿截图样式 */
        .article-info {
            padding: 14px 12px;
            background: #fff;
        }
        
        .article-date {
            font-size: 0.9rem;
            color: #999;
            font-weight: 400;
            margin-bottom: 5px;
            letter-spacing: 0.3px;
        }
        
        .article-title {
            font-size: 1.05rem;
            color: #222;
            font-weight: 600;
            line-height: 1.4;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        
        /* === 通用预览层 === */
        .preview-overlay {
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, .96);
            z-index: 9999;
            display: none;
            flex-direction: column;
            user-select: none;
        }

        .preview-header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            height: 60px;
            z-index: 10001;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 15px;
            color: #fff;
        }

        .preview-header-title {
            position: absolute;
            left: 50%;
            transform: translateX(-50%);
            font-size: 1rem;
            font-weight: 500;
            max-width: 60%;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            text-align: center;
            color: #fff;
            text-decoration: none;
            cursor: pointer;
            padding: 8px 16px;
            border-radius: 20px;
            transition: background 0.3s;
        }
        
        .preview-header-title:hover {
            background: rgba(255,255,255,0.1);
        }

        .preview-btn {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: rgba(255,255,255,0.1);
            border: none;
            color: #fff;
            font-size: 24px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background 0.3s;
            text-decoration: none;
            z-index: 2;
        }

        .preview-btn:hover {background: rgba(255,255,255,0.2);}

        .header-spacer {
            width: 40px;
            height: 40px;
        }

        .preview-main {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            margin-top: 60px;
            margin-bottom: 100px;
            overflow: hidden;
        }

        .preview-img-wrapper {
            width: 100%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            touch-action: none;
        }

        .preview-img {
            max-width: 90%;
            max-height: 80vh;
            object-fit: contain;
            border-radius: 4px;
            transition: transform 0.3s ease;
            user-select: none;
            -webkit-user-drag: none;
            box-shadow: 0 4px 20px rgba(0,0,0,0.5);
        }

        .preview-nav {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            width: 44px;
            height: 44px;
            border-radius: 50%;
            background: rgba(255, 255, 255, .15);
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 20px;
            border: none;
            backdrop-filter: blur(4px);
            transition: all 0.3s;
            z-index: 10;
        }

        .preview-nav:hover {
            background: rgba(255, 255, 255, .3);
            transform: translateY(-50%) scale(1.1);
        }

        .preview-nav.prev { left: 15px; }
        .preview-nav.next { right: 15px; }
        .preview-nav:disabled {opacity: 0.3; cursor: not-allowed;}

        .preview-footer {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: rgba(0,0,0,0.8);
            backdrop-filter: blur(10px);
            z-index: 10000;
            padding: 10px 15px 20px;
        }

        .preview-counter {
            text-align: center;
            color: rgba(255,255,255,0.7);
            font-size: 0.9rem;
            margin-bottom: 10px;
            font-weight: 500;
        }

        .thumb-list {
            display: flex;
            gap: 8px;
            justify-content: center;
            overflow-x: auto;
            padding: 5px;
            scrollbar-width: thin;
            scrollbar-color: rgba(255,255,255,.2) transparent;
        }
        
        .thumb-list::-webkit-scrollbar {height: 4px;}
        .thumb-list::-webkit-scrollbar-thumb {
            background: rgba(255,255,255,.2);
            border-radius: 2px;
        }

        .thumb-item {
            width: 60px;
            height: 45px;
            border-radius: 4px;
            overflow: hidden;
            cursor: pointer;
            border: 2px solid transparent;
            transition: all 0.3s;
            flex-shrink: 0;
            opacity: 0.6;
        }

        .thumb-item img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .thumb-item.active {
            border-color: var(--theme);
            opacity: 1;
            transform: scale(1.05);
        }

        .thumb-item:hover {opacity: 0.9;}
        
        /* === 右下角按钮组 === */
        .float-buttons{
            position:fixed;
            right:20px;
            bottom:30px;
            z-index:100;
            display:flex;
            flex-direction:column;
            gap:12px;
        }
        .float-btn{
            width:50px;
            height:50px;
            border-radius:50%;
            color:#fff;
            border:none;
            cursor:pointer;
            display:flex;
            align-items:center;
            justify-content:center;
            font-size:20px;
            box-shadow:0 4px 12px rgba(0,0,0,.3);
            transition:all 0.3s ease;
            text-decoration:none;
        }
        .float-btn:hover{transform:scale(1.1);}
        .float-btn.top{
            background:var(--theme);
            opacity:0;
            transform:translateY(20px);
            pointer-events:none;
        }
        .float-btn.top.visible{
            opacity:1;
            transform:translateY(0);
            pointer-events:auto;
        }
        .float-btn.home{background:#2d2d2d;}
        
        .empty-icon {
            font-size: 4rem;
            color: #ccc;
            margin-bottom: 15px;
        }
        
        /* === 响应式 === */
        @media (min-width: 768px) {
            .gallery-2col {gap: 20px; padding: 12px;}
            .gallery-3col {gap:12px;}
            header{margin:56px 0 0;height:40vh;}
            .header-title{font-size:2.2rem;}
            .header-subtitle{font-size:1rem;}
            main{padding:20px;}
            
            .article-info {padding: 16px 14px;}
            .article-date {font-size: 0.95rem;}
            .article-title {font-size: 1.1rem;}
            
            .preview-nav.prev { left: 30px; }
            .preview-nav.next { right: 30px; }
            .preview-btn, .header-spacer {width: 44px; height: 44px;}
        }
        
        @media (max-width: 600px){
            .top-bar{height:48px;}
            .top-bar-title{font-size:1.1rem;}
            header{height:30vh;min-height:180px;margin:48px 0 0;}
            .header-content{padding:20px;}
            .header-title{font-size:1.5rem;}
            .header-subtitle{font-size:0.8rem;}
            main{padding:5px;}
            
            .gallery-2col {gap: 12px; padding: 4px;}
            .article-card {border-radius: 12px;}
            .stack-container, .stack-main, 
            .article-card:not(.single) .stack-container::before,
            .article-card:not(.single) .stack-container::after {
                border-radius: 12px 12px 0 0;
            }
            .article-info {padding: 12px 10px;}
            .article-date {font-size: 0.85rem;}
            .article-title {font-size: 1rem;}
            
            .gallery-3col{gap:6px;}
            .float-buttons{right:15px;bottom:20px;}
            .float-btn{width:45px;height:45px;font-size:18px;}
            
            .preview-nav {width: 36px; height: 36px; font-size: 16px;}
            .preview-nav.prev { left: 10px; }
            .preview-nav.next { right: 10px; }
            .preview-header {padding: 0 10px; height: 50px;}
            .preview-header-title {font-size: 0.9rem; max-width: 50%;}
            .thumb-item {width: 50px; height: 38px;}
            .preview-btn, .header-spacer {width: 36px; height: 36px; font-size: 20px;}
        }
    </style>
</head>
<body>
    <!-- 顶栏 -->
    <div class="top-bar">
        <a href="<?php echo \Widget\Options::alloc()->siteUrl(); ?>" class="top-bar-title"><?php echo htmlspecialchars($albumTitle); ?></a>
    </div>

    <div class="page-container">
        <!-- 头部大图 -->
        <header>
            <div class="header-content">
                <div class="header-title"><?php echo htmlspecialchars($albumTitle); ?></div>
                <div class="header-subtitle"><?php echo htmlspecialchars($albumDesc); ?></div>
            </div>
        </header>

        <main>
            <?php if (empty($allArticles)): ?>
                <div style="text-align:center; padding:60px;">
                    <div class="empty-icon">&#128444;</div>
                    <p style="color:#888; font-weight:300;">暂无图片</p>
                </div>
            <?php else: ?>
                <?php if ($gridColumns == 2): ?>
                    <!-- === 双列文章堆叠模式（白色卡片样式） === -->
                    <div class="gallery-2col" id="gallery2col">
                        <?php 
                        $articleIndex = 0;
                        foreach ($allArticles as $article): 
                            $isSingle = $article['count'] <= 1;
                            $firstImg = $article['images'][0];
                            // 如果有第二张图，用于堆叠背景
                            $secondImg = $article['images'][1]['thumb'] ?? null;
                            $thirdImg = $article['images'][2]['thumb'] ?? null;
                        ?>
                            <div class="article-card <?php echo $isSingle ? 'single' : ''; ?>" 
                                 data-index="<?php echo $articleIndex; ?>"
                                 data-cid="<?php echo $article['cid']; ?>">
                                
                                <div class="stack-container" 
                                     data-second="<?php echo htmlspecialchars($secondImg ?? ''); ?>"
                                     data-third="<?php echo htmlspecialchars($thirdImg ?? ''); ?>">
                                    
                                    <div class="stack-main">
                                        <img src="<?php echo htmlspecialchars($firstImg['thumb']); ?>" 
                                             alt="<?php echo htmlspecialchars($article['title']); ?>" 
                                             loading="lazy">
                                    </div>
                                    
                                    <?php if (!$isSingle): ?>
                                    <div class="image-count">
                                        <?php echo $article['count']; ?>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="article-info">
                                    <div class="article-date"><?php echo htmlspecialchars($article['date']); ?></div>
                                    <div class="article-title"><?php echo htmlspecialchars($article['title']); ?></div>
                                </div>
                            </div>
                        <?php 
                            $articleIndex++;
                        endforeach; 
                        ?>
                    </div>
                    
                <?php else: ?>
                    <!-- === 三列普通瀑布流模式 === -->
                    <div class="gallery-3col" id="gallery3col">
                        <?php 
                        $flatImages = [];
                        foreach ($allArticles as $article) {
                            foreach ($article['images'] as $img) {
                                $flatImages[] = [
                                    'url' => $img['url'],
                                    'thumb' => $img['thumb'],
                                    'title' => $article['title'],
                                    'permalink' => $article['permalink']
                                ];
                            }
                        }
                        
                        $globalIndex = 0;
                        foreach ($flatImages as $img): 
                        ?>
                            <div class="polaroid" 
                                 data-index="<?php echo $globalIndex; ?>"
                                 data-url="<?php echo htmlspecialchars($img['url']); ?>" 
                                 data-title="<?php echo htmlspecialchars($img['title']); ?>"
                                 data-thumb="<?php echo htmlspecialchars($img['thumb']); ?>"
                                 data-permalink="<?php echo htmlspecialchars($img['permalink']); ?>">
                                <img src="<?php echo htmlspecialchars($img['thumb']); ?>" alt="" loading="lazy">
                            </div>
                        <?php 
                            $globalIndex++;
                        endforeach; 
                        ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </main>
    </div>

    <!-- 右下角按钮组 -->
    <div class="float-buttons">
        <button class="float-btn top" id="backToTop">&#8593;</button>
        <a href="<?php echo \Widget\Options::alloc()->siteUrl(); ?>" class="float-btn home">&#8962;</a>
    </div>

    <!-- 通用全屏预览层 -->
    <div class="preview-overlay" id="previewOverlay">
        <div class="preview-header">
            <div class="header-spacer"></div>
            <a class="preview-header-title" id="previewTitleLink" href="#" target="_blank">图片标题</a>
            <button class="preview-btn" id="previewClose">&#10005;</button>
        </div>
        
        <div class="preview-main" id="previewMain">
            <button class="preview-nav prev" id="previewPrev">&#8592;</button>
            <div class="preview-img-wrapper" id="imgWrapper">
                <img class="preview-img" id="previewImg" src="" alt="" draggable="false">
            </div>
            <button class="preview-nav next" id="previewNext">&#8594;</button>
        </div>
        
        <div class="preview-footer">
            <div class="preview-counter" id="previewCounter">1 / 5</div>
            <div class="thumb-list" id="thumbList"></div>
        </div>
    </div>

    <script>
        const allArticles = <?php echo json_encode($allArticles); ?>;
        let flatImages = [];
        let currentMode = '<?php echo $gridColumns == 2 ? 'article' : 'single'; ?>';
        
        if (currentMode === 'single') {
            allArticles.forEach(article => {
                article.images.forEach(img => {
                    flatImages.push({
                        url: img.url,
                        thumb: img.thumb,
                        title: article.title,
                        permalink: article.permalink
                    });
                });
            });
        }
        
        let currentArticleIndex = -1;
        let currentImageIndex = 0;
        let currentImages = [];
        let currentPermalink = '';
        
        const previewOverlay = document.getElementById('previewOverlay');
        const previewImg = document.getElementById('previewImg');
        const previewTitleLink = document.getElementById('previewTitleLink');
        const previewCounter = document.getElementById('previewCounter');
        const thumbList = document.getElementById('thumbList');
        const previewPrev = document.getElementById('previewPrev');
        const previewNext = document.getElementById('previewNext');
        const previewClose = document.getElementById('previewClose');
        
        // 动态设置堆叠背景图
        document.querySelectorAll('.article-card:not(.single) .stack-container').forEach(container => {
            const second = container.getAttribute('data-second');
            const third = container.getAttribute('data-third');
            const card = container.closest('.article-card');
            const cid = card.dataset.cid;
            
            if (second || third) {
                const styleId = 'stack-style-' + cid;
                if (!document.getElementById(styleId)) {
                    const style = document.createElement('style');
                    style.id = styleId;
                    let css = '';
                    if (second) {
                        css += `.article-card[data-cid="${cid}"] .stack-container::before { background-image: url(${second}); }`;
                    }
                    if (third) {
                        css += `.article-card[data-cid="${cid}"] .stack-container::after { background-image: url(${third}); }`;
                    }
                    style.textContent = css;
                    document.head.appendChild(style);
                }
            }
        });
        
        function openArticlePreview(articleIdx) {
            currentArticleIndex = articleIdx;
            const article = allArticles[articleIdx];
            currentImages = article.images;
            currentImageIndex = 0;
            currentPermalink = article.permalink;
            
            previewTitleLink.textContent = article.title;
            previewTitleLink.href = article.permalink;
            
            updatePreview();
            previewOverlay.style.display = 'flex';
            document.body.style.overflow = 'hidden';
        }
        
        function openSinglePreview(flatIndex) {
            currentImages = flatImages;
            currentImageIndex = flatIndex;
            currentPermalink = flatImages[flatIndex].permalink;
            
            previewTitleLink.textContent = flatImages[flatIndex].title;
            previewTitleLink.href = currentPermalink;
            
            updatePreview();
            previewOverlay.style.display = 'flex';
            document.body.style.overflow = 'hidden';
        }
        
        function updatePreview() {
            const img = currentImages[currentImageIndex];
            previewImg.src = img.url;
            previewCounter.textContent = `${currentImageIndex + 1} / ${currentImages.length}`;
            
            thumbList.innerHTML = currentImages.map((img, idx) => `
                <div class="thumb-item ${idx === currentImageIndex ? 'active' : ''}" data-index="${idx}">
                    <img src="${img.thumb}" alt="">
                </div>
            `).join('');
            
            thumbList.querySelectorAll('.thumb-item').forEach(item => {
                item.addEventListener('click', () => {
                    currentImageIndex = parseInt(item.dataset.index);
                    updatePreview();
                });
            });
            
            previewPrev.style.opacity = currentImageIndex === 0 ? '0.3' : '1';
            previewNext.style.opacity = currentImageIndex === currentImages.length - 1 ? '0.3' : '1';
        }
        
        function prevImage() {
            if (currentImageIndex > 0) {
                currentImageIndex--;
                updatePreview();
            }
        }
        
        function nextImage() {
            if (currentImageIndex < currentImages.length - 1) {
                currentImageIndex++;
                updatePreview();
            }
        }
        
        function closePreview() {
            previewOverlay.style.display = 'none';
            document.body.style.overflow = '';
            currentImages = [];
            currentImageIndex = 0;
            currentArticleIndex = -1;
            currentPermalink = '';
        }
        
        document.querySelectorAll('.article-card').forEach((card, idx) => {
            card.addEventListener('click', () => openArticlePreview(idx));
        });
        
        document.querySelectorAll('.gallery-3col .polaroid').forEach((item, idx) => {
            item.addEventListener('click', () => openSinglePreview(idx));
        });
        
        previewClose.addEventListener('click', closePreview);
        previewPrev.addEventListener('click', prevImage);
        previewNext.addEventListener('click', nextImage);
        
        previewOverlay.addEventListener('click', (e) => {
            if (e.target === previewOverlay || e.target.id === 'previewMain') {
                closePreview();
            }
        });
        
        document.addEventListener('keydown', (e) => {
            if (previewOverlay.style.display !== 'flex') return;
            if (e.key === 'ArrowLeft') prevImage();
            if (e.key === 'ArrowRight') nextImage();
            if (e.key === 'Escape') closePreview();
        });
        
        let touchStartX = 0;
        const imgWrapper = document.getElementById('imgWrapper');
        
        imgWrapper.addEventListener('touchstart', (e) => {
            touchStartX = e.changedTouches[0].screenX;
        }, { passive: true });
        
        imgWrapper.addEventListener('touchend', (e) => {
            const diff = touchStartX - e.changedTouches[0].screenX;
            if (Math.abs(diff) > 50) {
                if (diff > 0) nextImage();
                else prevImage();
            }
        }, { passive: true });
        
        const backToTopBtn = document.getElementById('backToTop');
        window.addEventListener('scroll', () => {
            if (window.scrollY > 300) backToTopBtn.classList.add('visible');
            else backToTopBtn.classList.remove('visible');
        });
        
        backToTopBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
        
        history.pushState(null, null, location.href);
        window.addEventListener('popstate', function(e) {
            if (previewOverlay.style.display === 'flex') {
                closePreview();
                history.pushState(null, null, location.href);
            } else {
                window.location.href = '<?php echo \Widget\Options::alloc()->siteUrl(); ?>';
            }
        });
    </script>
</body>
</html>
