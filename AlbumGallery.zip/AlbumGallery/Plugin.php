<?php

namespace TypechoPlugin\AlbumGallery;

use Typecho\Plugin\PluginInterface;
use Typecho\Widget\Helper\Form;
use Typecho\Widget\Helper\Form\Element\Text;
use Typecho\Widget\Helper\Form\Element\Radio;
use Utils\Helper;  // 引入 Helper 类

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * 记忆相册 Lin.
 *
 * @package AlbumGallery
 * @author Lin./https://linyu.live
 * @version 1.0.0
 */
class Plugin implements PluginInterface
{
    /**
     * 激活插件方法
     */
    public static function activate()
    {
        // 使用 Helper 添加路由（Typecho 1.3.0 正确方式）
        Helper::addRoute('album', '/album', 'AlbumGallery_Action', 'render');
        
        return _t('相册插件已激活，访问 /album 查看相册');
    }

    /**
     * 禁用插件方法
     */
    public static function deactivate()
    {
        // 使用 Helper 移除路由
        Helper::removeRoute('album');
        
        return _t('相册插件已禁用');
    }

    /**
     * 获取插件配置面板
     */
    public static function config(Form $form)
    {
        // 相册标题
        $title = new Text('title', null, '记忆相册', _t('相册标题'), _t('显示在相册页面顶部的标题'));
        $form->addInput($title);
        
        // 相册副标题
        $description = new Text('description', null, 'Scenery along the way', _t('相册副标题'), _t('支持使用 {year} 作为当前年份占位符'));
        $form->addInput($description);
        
        // 默认分类ID
        $category = new Text('category', null, '2', _t('默认分类ID'), _t('默认提取哪个分类下的文章图片（可在页面URL参数覆盖，如 ?category=3）'));
        $form->addInput($category->addRule('isInteger', _t('必须是数字')));
        
        // 背景音乐URL
        $musicUrl = new Text('musicUrl', null, 'https://music.163.com/song/media/outer/url?id=1330348068.mp3', _t('背景音乐URL'), _t('网易云音乐外链或其他MP3地址'));
        $form->addInput($musicUrl);
        
        // 音乐标题
        $musicTitle = new Text('musicTitle', null, '买辣椒也用券 - 起风了', _t('音乐标题'), _t('播放器显示的歌曲信息'));
        $form->addInput($musicTitle);
        
        // 七牛云域名
        $qiniuDomain = new Text('qiniuDomain', null, '', _t('七牛云域名'), _t('如：your-bucket.qiniudn.com（留空则不启用）'));
        $form->addInput($qiniuDomain);
        
        // 又拍云域名
        $upyunDomain = new Text('upyunDomain', null, '', _t('又拍云域名'), _t('如：your-bucket.b0.upaiyun.com（留空则不启用）'));
        $form->addInput($upyunDomain);
        
        // 阿里云OSS域名
        $ossDomain = new Text('ossDomain', null, '', _t('阿里云OSS域名'), _t('如：your-bucket.oss-cn-hangzhou.aliyuncs.com（留空则不启用）'));
        $form->addInput($ossDomain);
        
        // 默认头部背景图
        $headerBg = new Text('headerBg', null, 'https://linyu.live/usr/themes/OneBlog/static/img/photo.jpg', _t('默认头部背景图'), _t('当没有图片时显示的默认背景'));
        $form->addInput($headerBg);
        
        // 缩略图宽度
        $thumbWidth = new Text('thumbWidth', null, '400', _t('缩略图宽度'), _t('像素值'));
        $form->addInput($thumbWidth->addRule('isInteger', _t('必须是数字')));
        
        // 缩略图高度
        $thumbHeight = new Text('thumbHeight', null, '300', _t('缩略图高度'), _t('像素值，0为自适应'));
        $form->addInput($thumbHeight->addRule('isInteger', _t('必须是数字')));
        
        // 裁剪模式
        $cropMode = new Radio('cropMode', ['0' => _t('自适应缩放'), '1' => _t('强制裁剪')], '1', _t('裁剪模式'));
        $form->addInput($cropMode);
    }

    /**
     * 个人用户的配置面板
     */
    public static function personalConfig(Form $form)
    {
    }
}
