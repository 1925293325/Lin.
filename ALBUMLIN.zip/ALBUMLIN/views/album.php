<?php
/**
 * 相册模板 - Lin. 
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="<?php echo \Widget\Options::alloc()->charset(); ?>">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    
    <!-- 本地字体：优先使用系统自带中文字体 -->
    <style>
        :root{
            --theme:#ff5a5f;
            --bg:#f5f5f5;
            /* 使用本地系统字体栈，无需下载 */
            --font-sans: -apple-system, "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "WenQuanYi Micro Hei", sans-serif;
            --font-serif: "Noto Serif SC", "Source Han Serif SC", "STSong", "SimSun", "FangSong", serif;
        }
        *{box-sizing:border-box;margin:0;padding:0;font-family:var(--font-sans);}
        body{background:var(--bg);color:#333;overflow-x:hidden;font-weight:400;line-height:1.6;}
        
        /* === PC端容器居中 === */
        @media (min-width: 768px) {
            body {
                background: #f0f0f0;
            }
            .page-container {
                max-width: 900px;
                margin: 0 auto;
                background: #fff;
                box-shadow: 0 0 20px rgba(0,0,0,0.08);
                min-height: 100vh;
            }
        }
        @media (min-width: 1200px) {
            .page-container {max-width: 1000px;}
        }
        
        /* 顶栏 - 纯白背景，标题可点击 */
        .top-bar{
            position:fixed;
            top:0;
            left:0;
            right:0;
            height:56px;
            background:#fff;
            z-index:1000;
            display:flex;
            align-items:center;
            justify-content:center;
            padding:0 20px;
            box-shadow:0 1px 3px rgba(0,0,0,.05);
        }
        .top-bar-title{
            font-size:1.2rem;
            font-weight:500;
            color:#333;
            letter-spacing:2px;
            font-family:var(--font-sans);
            text-decoration:none;
            transition:opacity 0.2s;
        }
        .top-bar-title:hover{
            opacity:0.7;
        }
        
        /* 头部样式 - 动态背景 */
        header{
            position:relative;
            height:35vh;
            min-height:220px;
            margin:56px 0 0;
            background:url("<?php echo htmlspecialchars($headerBg); ?>") center/cover;
            display:flex;
            align-items:flex-end;
            justify-content:flex-start;
            overflow:hidden;
        }
        header::after{
            content:"";
            position:absolute;
            inset:0;
            background:linear-gradient(180deg,rgba(0,0,0,.1) 0%,rgba(0,0,0,.5) 100%);
        }
        
        /* 头部文字 - 左下角 */
        .header-content{
            position:relative;
            z-index:2;
            padding:25px 30px;
            text-align:left;
            color:#fff;
        }
        .header-title{
            font-size:1.8rem;
            font-weight:600;
            letter-spacing:4px;
            margin-bottom:8px;
            font-family:var(--font-serif);
            text-shadow:0 2px 8px rgba(0,0,0,.5);
        }
        .header-subtitle{
            font-size:0.9rem;
            font-weight:300;
            letter-spacing:2px;
            opacity:.9;
            text-shadow:0 1px 4px rgba(0,0,0,.4);
            font-family:var(--font-serif);
        }
        
        /* === 相册主体 === */
        main{
            max-width:100%;
            margin:0;
            padding:20px;
            background:#fff;
        }
        
        .section-title{
            font-size:1.5rem;
            font-weight:600;
            margin-bottom:10px;
            color:#333;
            font-family:var(--font-serif);
            letter-spacing:2px;
        }
        
        /* === 图片网格 === */
        .gallery{
            display:grid;
            gap:8px;
            background:#fff;
            grid-template-columns:repeat(<?php echo $gridColumns; ?>, 1fr);
        }
        .polaroid{
            position:relative;
            background:#fff;
            overflow:hidden;
            cursor:zoom-in;
            transition:transform 0.2s ease;
            border-radius:4px;
        }
        .polaroid:hover{
            transform:scale(1.02);
            z-index:10;
        }
        .polaroid::before{
            content:"";
            display:block;
            padding-bottom:100%;
        }
        .polaroid img{
            position:absolute;
            top:0;
            left:0;
            width:100%;
            height:100%;
            object-fit:cover;
            display:block;
        }
        
        /* === 预览层 === */
        .preview-overlay {
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, .96);
            z-index: 9999;
            display: none;
            align-items: center;
            justify-content: center;
            user-select: none;
            touch-action: pan-y;
        }

        .preview-container {
            width: 100%;
            height: 100%;
            max-width: 900px;
            display: flex;
            flex-direction: column;
            padding: 60px 20px 20px;
            position: relative;
        }

        .preview-close-fixed {
            position: fixed;
            top: 15px;
            right: 15px;
            width: 44px;
            height: 44px;
            border-radius: 50%;
            background: rgba(255, 255, 255, .15);
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 20px;
            font-weight: 300;
            z-index: 10000;
            border: none;
            backdrop-filter: blur(10px);
            transition:all 0.3s;
        }

        .preview-close-fixed:hover {
            background: rgba(255, 255, 255, .25);
            transform:rotate(90deg);
        }

        .preview-main {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            min-height: 0;
            overflow: hidden;
        }

        .preview-img-wrapper {
            position: relative;
            width: 100%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            touch-action: none;
        }

        .preview-img {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
            border-radius: 8px;
            transition: transform 0.3s ease;
            user-select: none;
            -webkit-user-drag: none;
            box-shadow:0 4px 20px rgba(0,0,0,.3);
        }

        .preview-nav {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            width: 44px;
            height: 44px;
            border-radius: 50%;
            background: rgba(255, 255, 255, .12);
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 18px;
            transition: all 0.3s;
            z-index: 10;
            border:none;
        }

        .preview-nav:hover {
            background: rgba(255, 255, 255, .25);
            transform:translateY(-50%) scale(1.1);
        }

        .preview-nav.prev { left: 5px; }
        .preview-nav.next { right: 5px; }

        .swipe-hint {
            position: absolute;
            bottom: 80px;
            left: 50%;
            transform: translateX(-50%);
            color: rgba(255, 255, 255, .5);
            font-size: 12px;
            pointer-events: none;
            opacity: 0;
            transition: opacity 0.3s;
            font-weight:300;
            letter-spacing:1px;
        }

        .swipe-hint.show {
            opacity: 1;
        }

        .preview-footer {
            flex-shrink: 0;
            padding-top: 15px;
        }

        .thumb-list {
            display: flex;
            gap: 8px;
            justify-content: center;
            overflow-x: auto;
            padding: 5px;
            scrollbar-width: thin;
            scrollbar-color: rgba(255,255,255,.2) transparent;
        }
        
        .thumb-list::-webkit-scrollbar {
            height: 4px;
        }
        .thumb-list::-webkit-scrollbar-thumb {
            background: rgba(255,255,255,.2);
            border-radius: 2px;
        }

        .thumb-item {
            width: 70px;
            height: 52px;
            border-radius: 6px;
            overflow: hidden;
            cursor: pointer;
            border: 2px solid transparent;
            transition: all 0.3s;
            flex-shrink: 0;
            opacity:0.7;
        }

        .thumb-item img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .thumb-item.active {
            border-color: var(--theme);
            opacity:1;
            transform:scale(1.05);
        }

        .thumb-item:hover {
            opacity:1;
            transform: scale(1.05);
        }
        
        /* === 右下角固定按钮组 === */
        .float-buttons{
            position:fixed;
            right:20px;
            bottom:30px;
            z-index:100;
            display:flex;
            flex-direction:column;
            gap:12px;
        }
        .float-btn{
            width:50px;
            height:50px;
            border-radius:50%;
            color:#fff;
            border:none;
            cursor:pointer;
            display:flex;
            align-items:center;
            justify-content:center;
            font-size:20px;
            box-shadow:0 4px 12px rgba(0,0,0,.3);
            transition:all 0.3s ease;
            text-decoration:none;
        }
        .float-btn:hover{
            transform:scale(1.1);
        }
        
        .float-btn.top{
            background:var(--theme);
            opacity:0;
            transform:translateY(20px);
            pointer-events:none;
        }
        .float-btn.top.visible{
            opacity:1;
            transform:translateY(0);
            pointer-events:auto;
        }
        .float-btn.top:hover{
            background:#ff4449;
        }
        
        .float-btn.home{
            background:#2d2d2d;
        }
        .float-btn.home:hover{
            background:#444;
        }
        
        /* === 空状态图标 === */
        .empty-icon {
            font-size: 4rem;
            color: #ccc;
            margin-bottom: 15px;
        }
        
        /* === 响应式 === */
        @media (min-width: 768px) {
            .gallery {gap:12px;}
            header{margin:56px 0 0;height:40vh;}
            .header-title{font-size:2.2rem;}
            .header-subtitle{font-size:1rem;}
            main{padding:20px;}
            .section-title{font-size:0rem;margin-bottom:5px;}
        }
        @media (max-width: 600px){
            .top-bar{height:48px;}
            .top-bar-title{font-size:1.1rem;letter-spacing:1px;}
            header{height:30vh;min-height:180px;margin:48px 0 0;}
            .header-content{padding:20px;}
            .header-title{font-size:1.5rem;letter-spacing:3px;}
            .header-subtitle{font-size:0.8rem;letter-spacing:1px;}
            main{padding:5px;}
            .gallery{gap:6px;}
            .section-title{font-size:0rem;margin-bottom:5px;}
            .float-buttons{right:15px;bottom:20px;}
            .float-btn{width:45px;height:45px;font-size:18px;}
            
            .preview-container { padding: 45px 10px 10px; }
            .preview-close-fixed { width: 40px; height: 40px; font-size: 16px; top:10px; right:10px;}
            .preview-nav { width: 36px; height: 36px; font-size: 16px; }
            .thumb-item { width: 55px; height: 40px; }
        }
    </style>
</head>
<body>
    <!-- 顶栏 - 标题点击返回博客主页 -->
    <div class="top-bar">
        <a href="<?php echo \Widget\Options::alloc()->siteUrl(); ?>" class="top-bar-title"><?php echo htmlspecialchars($albumTitle); ?></a>
    </div>

    <div class="page-container">
        <!-- 头部大图 - 动态背景 -->
        <header>
            <div class="header-content">
                <div class="header-title"><?php echo htmlspecialchars($albumTitle); ?></div>
                <div class="header-subtitle"><?php echo htmlspecialchars($albumDesc); ?></div>
            </div>
        </header>

        <main>
            <div class="section-title"></div>
            
            <?php if (empty($allImages)): ?>
                <div style="text-align:center; padding:60px;">
                    <!-- Unicode 替代 Font Awesome 的 fa-images -->
                    <div class="empty-icon">&#128444;</div>
                    <p style="color:#888; font-weight:300;">暂无图片</p>
                </div>
            <?php else: ?>
                <div class="gallery">
                    <?php 
                    $globalIndex = 0;
                    foreach ($allImages as $img): 
                        $imgUrl = is_array($img) ? ($img['url'] ?? '') : $img;
                        $imgThumb = is_array($img) ? ($img['thumb'] ?? $imgUrl) : $img;
                        $imgTitle = is_array($img) ? ($img['title'] ?? '') : '';
                    ?>
                        <div class="polaroid" 
                             data-index="<?php echo $globalIndex; ?>"
                             data-url="<?php echo htmlspecialchars($imgUrl); ?>" 
                             data-title="<?php echo htmlspecialchars($imgTitle); ?>"
                             data-thumb="<?php echo htmlspecialchars($imgThumb); ?>">
                            <img src="<?php echo htmlspecialchars($imgThumb); ?>" alt="<?php echo htmlspecialchars($imgTitle); ?>" loading="lazy">
                        </div>
                        <?php $globalIndex++; ?>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </main>
    </div>

    <!-- 右下角固定按钮组 (使用 Unicode 符号) -->
    <div class="float-buttons">
        <button class="float-btn top" id="backToTop" title="返回顶部">
            &#8593; <!-- ↑ -->
        </button>
        <a href="<?php echo \Widget\Options::alloc()->siteUrl(); ?>" class="float-btn home" title="返回首页">
            &#8962; <!-- ⌂ -->
        </a>
    </div>

    <!-- 预览层 -->
    <div class="preview-overlay" id="previewOverlay">
        <button class="preview-close-fixed" id="previewClose" title="关闭">&#10005;</button> <!-- ✕ -->
        
        <div class="preview-container">
            <div class="preview-main" id="previewMain">
                <button class="preview-nav prev" id="previewPrev" aria-label="上一张">
                    &#8592; <!-- ← -->
                </button>
                <div class="preview-img-wrapper" id="imgWrapper">
                    <img class="preview-img" id="previewImg" src="" alt="" draggable="false">
                </div>
                <button class="preview-nav next" id="previewNext" aria-label="下一张">
                    &#8594; <!-- → -->
                </button>
                <div class="swipe-hint" id="swipeHint">左右滑动切换图片</div>
            </div>
            
            <div class="preview-footer">
                <div class="thumb-list" id="thumbList"></div>
            </div>
        </div>
    </div>

    <script>
        // 手机返回键处理 - 返回博客首页
        history.pushState(null, null, location.href);
        window.addEventListener('popstate', function(e) {
            const overlay = document.getElementById('previewOverlay');
            if (overlay.style.display === 'flex') {
                overlay.style.display = 'none';
                document.body.style.overflow = '';
                history.pushState(null, null, location.href);
            } else {
                window.location.href = '<?php echo \Widget\Options::alloc()->siteUrl(); ?>';
            }
        });

        const allImages = [];
        document.querySelectorAll('.polaroid').forEach(el => {
            allImages.push({
                url: el.dataset.url,
                thumb: el.dataset.thumb,
                title: el.dataset.title
            });
        });

        const overlay = document.getElementById('previewOverlay');
        const previewImg = document.getElementById('previewImg');
        const previewClose = document.getElementById('previewClose');
        const previewPrev = document.getElementById('previewPrev');
        const previewNext = document.getElementById('previewNext');
        const thumbList = document.getElementById('thumbList');
        const imgWrapper = document.getElementById('imgWrapper');
        const swipeHint = document.getElementById('swipeHint');
        let currentIndex = 0;

        let touchStartX = 0;
        let touchEndX = 0;
        let touchStartY = 0;
        let isSwiping = false;

        function generateThumbs() {
            thumbList.innerHTML = allImages.map((img, idx) => `
                <div class="thumb-item ${idx === currentIndex ? 'active' : ''}" data-index="${idx}">
                    <img src="${img.thumb}" alt="">
                </div>
            `).join('');
            
            thumbList.querySelectorAll('.thumb-item').forEach(item => {
                item.addEventListener('click', () => {
                    currentIndex = parseInt(item.dataset.index);
                    updatePreview();
                });
            });
        }

        function updatePreview() {
            const current = allImages[currentIndex];
            previewImg.src = current.url;
            
            thumbList.querySelectorAll('.thumb-item').forEach((item, idx) => {
                item.classList.toggle('active', idx === currentIndex);
                if (idx === currentIndex) {
                    item.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
                }
            });
        }

        function openPreview(index) {
            currentIndex = index;
            generateThumbs();
            updatePreview();
            overlay.style.display = 'flex';
            document.body.style.overflow = 'hidden';
            
            if (!localStorage.getItem('previewHintShown')) {
                swipeHint.classList.add('show');
                setTimeout(() => {
                    swipeHint.classList.remove('show');
                }, 2000);
                localStorage.setItem('previewHintShown', 'true');
            }
        }

        function closePreview() {
            overlay.style.display = 'none';
            document.body.style.overflow = '';
        }

        function prevImage() {
            currentIndex = (currentIndex - 1 + allImages.length) % allImages.length;
            updatePreview();
            showSwipeFeedback('left');
        }

        function nextImage() {
            currentIndex = (currentIndex + 1) % allImages.length;
            updatePreview();
            showSwipeFeedback('right');
        }

        function showSwipeFeedback(direction) {
            const img = previewImg;
            img.style.transform = `translateX(${direction === 'left' ? '20px' : '-20px'})`;
            setTimeout(() => {
                img.style.transform = 'translateX(0)';
            }, 300);
        }

        document.querySelectorAll('.polaroid').forEach((el) => {
            el.addEventListener('click', () => {
                const index = parseInt(el.dataset.index);
                openPreview(index);
            });
        });

        previewClose.onclick = closePreview;
        previewPrev.onclick = prevImage;
        previewNext.onclick = nextImage;

        overlay.onclick = (e) => {
            if (e.target === overlay) closePreview();
        };

        document.addEventListener('keydown', (e) => {
            if (overlay.style.display !== 'flex') return;
            if (e.key === 'ArrowLeft') prevImage();
            if (e.key === 'ArrowRight') nextImage();
            if (e.key === 'Escape') closePreview();
        });

        imgWrapper.addEventListener('touchstart', (e) => {
            touchStartX = e.changedTouches[0].screenX;
            touchStartY = e.changedTouches[0].screenY;
            isSwiping = false;
        }, { passive: true });

        imgWrapper.addEventListener('touchmove', (e) => {
            if (!touchStartX) return;
            
            const touchX = e.changedTouches[0].screenX;
            const touchY = e.changedTouches[0].screenY;
            const diffX = touchStartX - touchX;
            const diffY = touchStartY - touchY;
            
            if (Math.abs(diffX) > Math.abs(diffY) && Math.abs(diffX) > 10) {
                isSwiping = true;
                previewImg.style.transform = `translateX(${-diffX * 0.3}px)`;
            }
        }, { passive: true });

        imgWrapper.addEventListener('touchend', (e) => {
            touchEndX = e.changedTouches[0].screenX;
            handleSwipe();
            touchStartX = 0;
            touchStartY = 0;
            previewImg.style.transform = '';
        });

        function handleSwipe() {
            if (!isSwiping) return;
            
            const swipeThreshold = 50;
            const diff = touchStartX - touchEndX;
            
            if (Math.abs(diff) > swipeThreshold) {
                if (diff > 0) {
                    nextImage();
                } else {
                    prevImage();
                }
            }
        }

        let mouseStartX = 0;
        let isMouseDown = false;

        imgWrapper.addEventListener('mousedown', (e) => {
            mouseStartX = e.screenX;
            isMouseDown = true;
            imgWrapper.style.cursor = 'grabbing';
        });

        imgWrapper.addEventListener('mousemove', (e) => {
            if (!isMouseDown) return;
            const diffX = mouseStartX - e.screenX;
            previewImg.style.transform = `translateX(${-diffX * 0.3}px)`;
        });

        imgWrapper.addEventListener('mouseup', (e) => {
            if (!isMouseDown) return;
            isMouseDown = false;
            imgWrapper.style.cursor = 'grab';
            
            const swipeThreshold = 50;
            const diff = mouseStartX - e.screenX;
            
            if (Math.abs(diff) > swipeThreshold) {
                if (diff > 0) {
                    nextImage();
                } else {
                    prevImage();
                }
            } else {
                previewImg.style.transform = '';
            }
        });

        imgWrapper.addEventListener('mouseleave', () => {
            if (isMouseDown) {
                isMouseDown = false;
                imgWrapper.style.cursor = 'grab';
                previewImg.style.transform = '';
            }
        });

        const backToTopBtn = document.getElementById('backToTop');
        
        window.addEventListener('scroll', () => {
            if (window.scrollY > 300) {
                backToTopBtn.classList.add('visible');
            } else {
                backToTopBtn.classList.remove('visible');
            }
        });

        backToTopBtn.addEventListener('click', () => {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    </script>
</body>
</html>
