<?php

namespace TypechoPlugin\ALBUMLIN;

use Typecho\Plugin\PluginInterface;
use Typecho\Widget\Helper\Form;
use Typecho\Widget\Helper\Form\Element\Text;
use Typecho\Widget\Helper\Form\Element\Radio;
use Utils\Helper;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * 相册 - Lin.
 *
 * @package ALBUMLIN
 * @author Lin./https://linyu.live
 * @version 1.0.3
 */
class Plugin implements PluginInterface
{
    /**
     * 激活插件方法
     */
    public static function activate()
    {
        Helper::addRoute('album', '/album', 'ALBUMLIN_Action', 'render');
        
        return _t('相册插件已激活，访问 你的域名/album 查看相册');
    }

    /**
     * 禁用插件方法
     */
    public static function deactivate()
    {
        Helper::removeRoute('album');
        
        return _t('相册插件已禁用');
    }

    /**
     * 获取插件配置面板
     */
    public static function config(Form $form)
    {
        // 相册标题（顶栏 + 首图大标题）
        $title = new Text('title', null, '我的相册', _t('相册标题'), _t('显示在顶栏和首图左下角的大标题'));
        $form->addInput($title);
        
        // 相册副标题（首图英文小字）
        $description = new Text('description', null, 'Scenery along the way', _t('相册副标题'), _t('显示在首图左下角的小字/英文'));
        $form->addInput($description);
        
        // 默认分类ID
        $category = new Text('category', null, '2', _t('默认分类ID'), _t('默认提取哪个分类下的文章图片（可在页面URL参数覆盖，如 ?category=3）'));
        $form->addInput($category->addRule('isInteger', _t('必须是数字')));
        
        // 头部背景图URL
        $headerBg = new Text('headerBg', null, 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=1200&q=80', _t('首图背景'), _t('相册页面顶部大图背景，建议尺寸 1200x600，可用复古相机或风景图'));
        $form->addInput($headerBg);
        
        // 网格布局列数
        $gridColumns = new Radio('gridColumns', 
            ['3' => _t('三列网格（小图，适合图片多）'), '2' => _t('双列网格（大图，适合图片少）')], 
            '3', 
            _t('网格布局')
        );
        $form->addInput($gridColumns);
    }

    /**
     * 个人用户的配置面板
     */
    public static function personalConfig(Form $form)
    {
    }
}
