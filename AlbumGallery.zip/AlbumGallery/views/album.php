<?php
/**
 * 相册模板
 * 变量由 Action.php 传入：
 * - $pageTitle: 页面标题
 * - $albumTitle: 相册主标题
 * - $albumDesc: 相册副标题
 * - $headerBg: 头部背景图
 * - $articles: 文章图片数据
 * - $allImages: 所有图片平铺数组
 * - $options: 插件配置对象
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="<?php echo \Widget\Options::alloc()->charset(); ?>">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* === 基础样式 === */
        :root{--theme:#ff5a5f;--bg:#fafafa;--glass:rgba(255,255,255,.15);}
        *{box-sizing:border-box;margin:0;padding:0;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial;}
        body{background:var(--bg);color:#333;overflow-x:hidden;}
        
        /* === 透明顶栏 === */
        .top-bar{position:fixed;top:0;left:0;right:0;height:56px;background:var(--glass);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border-bottom:1px solid rgba(255,255,255,.2);z-index:1000;display:flex;align-items:center;justify-content:center;padding:0 20px;}
        .top-bar-title{font-size:1.3rem;font-weight:600;color:#fff;letter-spacing:2px;text-shadow:0 2px 4px rgba(0,0,0,.3);}
        
        /* === 头部样式 === */
        header{position:relative;height:50vh;min-height:300px;background:url("<?php echo htmlspecialchars($headerBg); ?>") center/cover;display:flex;align-items:center;justify-content:center;border-radius:0 0 30px 30px;overflow:hidden;margin-top:0;}
        header::after{content:"";position:absolute;inset:0;background:linear-gradient(180deg,rgba(0,0,0,.3) 0%,rgba(0,0,0,.5) 100%);}
        
        /* === 副标题居中放大 === */
        .header-content{position:relative;z-index:2;text-align:center;color:#fff;display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;padding-top:30px;}
        .header-subtitle{font-size:1.8rem;font-weight:400;letter-spacing:3px;opacity:.95;text-shadow:0 2px 8px rgba(0,0,0,.4);margin-top:-20px;}
        
        /* === 音乐播放器样式 === */
        .music-player{position:sticky;top:66;z-index:1001;max-width:800px;margin:40px auto 30px;background:rgba(255,255,255,.8);backdrop-filter:blur(12px);border:1px solid rgba(255,255,255,.6);border-radius:18px;box-shadow:0 8px 32px rgba(0,0,0,.08);padding:18px 18px;display:flex;align-items:center;gap:14px;}
        .player-btn{width:46px;height:46px;border-radius:50%;background:var(--theme);color:#fff;border:none;cursor:pointer;display:grid;place-content:center;font-size:20px;}
        .tri-play {display: inline-block;width: 0;height: 0;border-style: solid;border-width: 10px 0 10px 16px;border-color: transparent transparent transparent #ffffff;margin-left: 2px;}
        .tri-pause {display: flex;align-items: center;justify-content: space-between;width: 16px;height: 16px;}
        .tri-pause::before,.tri-pause::after {content: '';display: block;width: 5px;height: 100%;background-color: #ffffff;}
        .player-info{flex:1;}
        .player-info .title{font-weight:600;margin-bottom:4px;font-size:14px;}
        .player-info .time{font-size:12px;color:#666;}
        .progress{width:100%;height:4px;background:rgba(0,0,0,.08);border-radius:2px;margin:6px 0;cursor:pointer;position:relative;}
        .progress-bar{height:100%;background:var(--theme);border-radius:2px;width:0%;}
        .volume{display:flex;align-items:center;gap:6px;}
        .volume input{width:90px;}
        
        /* === 相册主体 === */
        main{max-width:900px;margin:0 auto;padding:0 20px 60px;}
        .section-title{font-size:1.5rem;margin:40px 0 20px;display:flex;align-items:center;gap:10px;}
        .section-title::before{content:"";width:5px;height:22px;background:var(--theme);border-radius:3px;}
        
        /* === 图片网格 === */
        .gallery{display:grid;grid-template-columns:repeat(2,1fr);gap:30px;}
        .polaroid{position:relative;background:#000;border:8px solid #000;border-radius:4px;box-shadow:0 0 0 2px #444,0 8px 24px rgba(0,0,0,.6);cursor:zoom-in;transform-origin:center;transition:transform 0.2s ease;}
        .polaroid:hover{transform:scale(1.02);}
        .polaroid::before,.polaroid::after{content:"";position:absolute;left:0;right:0;height:10px;background:repeating-linear-gradient(90deg,#000 0 6px,transparent 6px 12px);}
        .polaroid::before{top:-10px;}
        .polaroid::after{bottom:-10px;}
        .polaroid img{width:100%;height:220px;object-fit:cover;display:block;}
        
        /* === 预览层 === */
        .preview-overlay{position:fixed;inset:0;background:rgba(0,0,0,.92);z-index:999;display:none;place-content:center;user-select:none;}
        .preview-box{position:relative;width:90vw;height:90vh;display:flex;align-items:center;justify-content:center;}
        .preview-close{position:absolute;top:20px;right:20px;width:46px;height:46px;border-radius:50%;background:rgba(30,30,30,.6);color:#fff;display:grid;place-content:center;cursor:pointer;font-size:28px;}
        .preview-nav{position:absolute;top:50%;transform:translateY(-50%);width:46px;height:46px;border-radius:50%;background:rgba(30,30,30,.6);color:#fff;display:grid;place-content:center;cursor:pointer;font-size:28px;}
        .preview-nav.prev{left:20px;}
        .preview-nav.next{right:20px;}
        .preview-img{max-width:100%;max-height:100%;border-radius:10px;box-shadow:0 8px 40px rgba(0,0,0,.5);}
        
        /* === 右下角固定按钮组 === */
        .float-buttons{position:fixed;right:20px;bottom:30px;z-index:100;display:flex;flex-direction:column;gap:12px;}
        .float-btn{width:50px;height:50px;border-radius:50%;color:#fff;border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:20px;box-shadow:0 4px 12px rgba(0,0,0,.3);transition:all 0.3s ease;text-decoration:none;}
        .float-btn:hover{transform:scale(1.1);}
        
        /* 返回顶部按钮 - 默认隐藏，滚动后显示 */
        .float-btn.top{background:var(--theme);opacity:0;transform:translateY(20px);pointer-events:none;}
        .float-btn.top.visible{opacity:1;transform:translateY(0);pointer-events:auto;}
        .float-btn.top:hover{background:#ff4449;}
        
        /* 返回首页按钮 - 始终显示 */
        .float-btn.home{background:#2d2d2d;}
        .float-btn.home:hover{background:#444;}
        
        /* === 响应式 === */
        @media (min-width: 768px) {
            .gallery {grid-template-columns: repeat(3, 1fr);gap: 20px;}
            .header-subtitle{font-size:2rem;}
        }
        @media (max-width: 600px){
            .top-bar{height:48px;}
            .top-bar-title{font-size:1.1rem;}
            .header-subtitle{font-size:1.4rem;}
            .music-player{margin-top:-100px;}
            .polaroid img{height:auto;aspect-ratio:1/1;}
            .float-buttons{right:15px;bottom:20px;}
            .float-btn{width:45px;height:45px;font-size:18px;}
        }
        @media(max-width: 480px){
            .music-player{margin-top:-80px;}
            .player-info .title{font-size:12px;}
        }
    </style>
</head>
<body>
    <!-- 透明顶栏 -->
    <div class="top-bar">
        <div class="top-bar-title"><?php echo htmlspecialchars($albumTitle); ?></div>
    </div>

    <!-- 头部大图 -->
    <header>
        <div class="header-content">
            <div class="header-subtitle"><?php echo htmlspecialchars($albumDesc); ?></div>
        </div>
    </header>

    <!-- 音乐播放器 -->
    <div class="music-player">
        <button id="playBtn" class="player-btn" title="播放/暂停"><span class="tri-play"></span></button>
        <div class="player-info">
            <div class="title"><?php echo htmlspecialchars($options->musicTitle); ?></div>
            <div class="progress" id="progressBar"><div class="progress-bar"></div></div>
            <div class="time"><span id="curTime">00:00</span> / <span id="totTime">00:00</span></div>
        </div>
        <div class="volume"><span style="font-size:18px;">🎼</span><input type="range" id="volumeRange" min="0" max="1" step="0.05" value="0.6"></div>
        <audio id="audio" src="<?php echo htmlspecialchars($options->musicUrl); ?>"></audio>
    </div>

    <main>
        <?php if (empty($articles)): ?>
            <div style="text-align:center; padding:60px;">
                <i class="fas fa-images" style="font-size:4rem; color:#ccc;"></i>
                <p style="margin-top:20px;">暂无图片</p>
            </div>
        <?php else: ?>
            <?php foreach ($articles as $article): ?>
                <h2 class="section-title"><?php echo htmlspecialchars($article['title']); ?></h2>
                <div class="gallery">
                    <?php foreach ($article['images'] as $img): ?>
                        <div class="polaroid" data-url="<?php echo htmlspecialchars($img['url']); ?>" data-title="<?php echo htmlspecialchars($img['title']); ?>">
                            <img src="<?php echo htmlspecialchars($img['thumb']); ?>" alt="<?php echo htmlspecialchars($img['title']); ?>" loading="lazy">
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </main>

    <!-- 右下角固定按钮组 -->
    <div class="float-buttons">
        <button class="float-btn top" id="backToTop" title="返回顶部">
            <i class="fas fa-arrow-up"></i>
        </button>
        <a href="<?php \Widget\Options::alloc()->siteUrl(); ?>" class="float-btn home" title="返回首页">
            <i class="fas fa-home"></i>
        </a>
    </div>

    <!-- 预览层 -->
    <div class="preview-overlay" id="previewOverlay">
        <div class="preview-box">
            <span class="preview-close" id="previewClose">&times;</span>
            <span class="preview-nav prev" id="previewPrev">&#8249;</span>
            <img class="preview-img" id="previewImg" src="" alt="">
            <span class="preview-nav next" id="previewNext">&#8250;</span>
        </div>
    </div>

    <script>
        // 收集所有图片用于预览
        const allImages = <?php echo json_encode(array_map(function($img) {
            return ['url' => $img['url'], 'title' => $img['title']];
        }, $allImages)); ?>;

        // 预览功能
        const overlay = document.getElementById('previewOverlay');
        const previewImg = document.getElementById('previewImg');
        const previewClose = document.getElementById('previewClose');
        const previewPrev = document.getElementById('previewPrev');
        const previewNext = document.getElementById('previewNext');
        let currentIndex = 0;

        // 为所有polaroid绑定点击事件
        document.querySelectorAll('.polaroid').forEach((el, index) => {
            el.addEventListener('click', () => {
                currentIndex = index;
                previewImg.src = allImages[currentIndex].url;
                overlay.style.display = 'grid';
                document.body.style.overflow = 'hidden';
            });
        });

        previewClose.onclick = () => {
            overlay.style.display = 'none';
            document.body.style.overflow = '';
        };

        previewPrev.onclick = () => {
            if (allImages.length === 0) return;
            currentIndex = (currentIndex - 1 + allImages.length) % allImages.length;
            previewImg.src = allImages[currentIndex].url;
        };

        previewNext.onclick = () => {
            if (allImages.length === 0) return;
            currentIndex = (currentIndex + 1) % allImages.length;
            previewImg.src = allImages[currentIndex].url;
        };

        overlay.onclick = (e) => {
            if (e.target === overlay) {
                overlay.style.display = 'none';
                document.body.style.overflow = '';
            }
        };

        // 键盘事件
        document.addEventListener('keydown', (e) => {
            if (overlay.style.display !== 'grid') return;
            if (e.key === 'ArrowLeft') previewPrev.click();
            if (e.key === 'ArrowRight') previewNext.click();
            if (e.key === 'Escape') previewClose.click();
        });

        // 音乐播放器功能
        const audio = document.getElementById('audio');
        const playBtn = document.getElementById('playBtn');
        const progressBar = document.querySelector('.progress-bar');
        const progress = document.getElementById('progressBar');
        const curTimeEl = document.getElementById('curTime');
        const totTimeEl = document.getElementById('totTime');
        const volRange = document.getElementById('volumeRange');

        playBtn.onclick = () => {
            if (audio.paused) {
                audio.play();
                playBtn.innerHTML = '<span class="tri-pause"></span>';
            } else {
                audio.pause();
                playBtn.innerHTML = '<span class="tri-play"></span>';
            }
        };

        audio.onloadedmetadata = () => {
            totTimeEl.textContent = fmtTime(audio.duration);
        };

        audio.ontimeupdate = () => {
            progressBar.style.width = `${(audio.currentTime / audio.duration) * 100}%`;
            curTimeEl.textContent = fmtTime(audio.currentTime);
        };

        progress.onclick = (e) => {
            const ratio = e.offsetX / progress.offsetWidth;
            audio.currentTime = ratio * audio.duration;
        };

        volRange.oninput = (e) => {
            audio.volume = e.target.value;
        };

        function fmtTime(sec) {
            const m = Math.floor(sec / 60);
            const s = Math.floor(sec % 60);
            return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
        }

        audio.onended = () => {
            playBtn.innerHTML = '<span class="tri-play"></span>';
        };

        // 返回顶部功能
        const backToTopBtn = document.getElementById('backToTop');
        
        // 滚动时显示/隐藏按钮
        window.addEventListener('scroll', () => {
            if (window.scrollY > 300) {
                backToTopBtn.classList.add('visible');
            } else {
                backToTopBtn.classList.remove('visible');
            }
        });

        // 点击返回顶部
        backToTopBtn.addEventListener('click', () => {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    </script>
</body>
</html>
